export const departments = [
    'All Departments',
    'Computer Science',
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology'
];

export const statuses = [
    'All Status',
    'active',
    'upcoming'
];
