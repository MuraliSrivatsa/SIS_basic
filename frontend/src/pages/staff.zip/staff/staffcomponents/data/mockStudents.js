const mockStudents = [
  { id: 1, name: 'John Doe', age: 16, grade: '10th', enrolled: true },
  { id: 2, name: 'Jane Smith', age: 15, grade: '9th', enrolled: false },
];

export default mockStudents;
